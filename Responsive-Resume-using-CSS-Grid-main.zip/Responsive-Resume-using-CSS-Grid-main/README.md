Newton Project
